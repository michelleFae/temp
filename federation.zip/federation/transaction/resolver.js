import {pubsub} from "../../../redis";
import {dbCreateUsersClient, dbIsValidUser} from '../../../dataStores/usersDbs/users.js';
import {dbCreateEventsClient, dbIsValidEvent} from '../../../dataStores/eventsDbs/events.js';
import {dbCreateTransactionClient, dbGetTransactions, dbGetTransaction, dbAddTransaction, dbGetTransactionIdToEventId, dbGetTransactionIdToUserId } from "../../../dataStores/transactionsDbs/transactions";

require('apollo-server');

// Define resolvers
export default {
  Query: {
    getTransactions: async (_, {userId}) => {
      // RETURN a list of transactions from the db
      return dataSources.transactionsAPI.getAllTransactions(userId);
    },
    getTransactionById: async (_, { transactionId }) => {
      // RETURN user transaction by id
      const transactions = dataSources.transactionsAPI.getTransactionsForUser(transactionId);
      return { userId, transactions };
    },
  },

  Transaction: {
    
    user: async (parent) => {
      // RETURN an user with userId - corresponding to the user that had the transaction corresponding to parent.transactionId
      let userId = dataSources.transactionsAPI.dbGetTransactionIdToUserId(parent.transactionId);
      return { __typename: "User", userId: userId };
    },

    // Reference resolver - used by services querying transaction entities
    __resolveReference(parent) {
      // RETURN the transaction with the same transactionId as parent.transactionId
      return dataSources.transactionsAPI.getTransactionById(parent.transactionId);
    }
  },
  User: {
    transactionsByUser: async (parent) => {
      // RETURN a list of transactions written by user with userId parent.userId
      return dataSources.transactionsAPI.getTransactionsForUser(parent.userId);
    }
  },
};
