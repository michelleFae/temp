import { gql } from 'apollo-server';

export default gql`
"""
A type to describe user transaction information.
"""
type Transaction @key(fields: "transactionId") {
  "Id of the transaction."
  transactionId: ID!
  "Time at which the transaction occurred."
  timestamp: String!
  "The purchased item."
  Fruit: String!
  "The user that bought the item."
  buyer: User!
  "Total price of the fruit."
  price: Float!
  "Total quantity (in kg) of purchased fruit."
  quantity: Int!
}

type Query {
  "The list of all transactions. Can filter on userId."
  transactions(userId: ID): [Transaction!]
  "Returns the transaction that matched the transactionId."
  transaction(transactionId: ID!): Transaction
}


extend type User @key(fields: "userId") {
  userId: ID!
  "List of transactions done by the user, across all products."
  transactionsByUser: [Transaction!]
}

`;