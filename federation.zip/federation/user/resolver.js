// Define resolvers
export default {
    Query: {
        user: async (_, { userId }) => {
            // RETURN the user with the matching userId
            // Note: the function signature can also be written as (parentObj, args, context, info), just like in graphQL.
            // Also, it doesn't need to be async
            return dataSources.usersAPI.getUser(userId);
        },
        users: async (_, {}) => {
            // RETURN list of all users
            return dataSources.usersAPI.getUsers();
        }
    },
    User: {
        // Reference resolver - used by services querying user entities
        __resolveReference(parent) {
          // RETURN the user with the same id as parent.userId
          return dataSources.usersAPI.getUser(parent.userId);
        }
    }
};