import { gql } from 'apollo-server';

/* 
Note: gql is a function which takes in a schema string. 
This is called a tagged template. 
See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals#tagged_templates for more info.
*/

export default gql`

  # User needs to be an Entity in order to be shared with other microservices.
  # The @key directive defines the entity's primary key, which is the id field in this case.
  # This primary key will be used as a unique reference for all implementing services
  
  """
  A type that describes the User.
  """
  type User @key(fields: "userId") {
    "Id of the user."
    userId: ID!

    "Name of the user."
    name: String!

    "Email id of the User."
    emailId: String!

    "Address of the user."
    address: String!
  }

  type Query {
    "The list of all available users"
    users: [User!]!
  
    "The details of a specific User"
    user(userId: String!): User
  }
 
`;